#pragma once
#include "Plant.h"
class Wall_nut :public Plant
{
public:
	Wall_nut();
	virtual~Wall_nut();
};

