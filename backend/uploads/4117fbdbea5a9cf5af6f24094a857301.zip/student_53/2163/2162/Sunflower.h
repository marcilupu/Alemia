#pragma once
#include "Plant.h"
class Sunflower :public Plant
{
public:
	Sunflower();
	virtual~Sunflower();
};

