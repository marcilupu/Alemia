#include "Peashooter.h"



Peashooter::Peashooter():Plant('P', 1000000,{10,12},100)
{
}


Peashooter::~Peashooter()
{
}
