#include "Zoombie.h"


Zoombie::Zoombie()
{


}


Zoombie::~Zoombie()
{
}
