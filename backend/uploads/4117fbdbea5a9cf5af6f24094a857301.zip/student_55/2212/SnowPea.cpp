#include "SnowPea.h"
int SnowPea::spawnTime = 4000;
int SnowPea::shootTime = 5000;