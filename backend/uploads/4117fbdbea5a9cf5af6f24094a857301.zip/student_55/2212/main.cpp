#include "Game.h"



int main() {
	Game& g = Game::getInstance();
	//g.playFirstLevel();
	return 0;
}