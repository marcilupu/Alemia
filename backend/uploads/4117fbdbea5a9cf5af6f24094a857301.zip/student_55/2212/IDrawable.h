#pragma once
class IDrawable
{
protected:
	int x;
	int y;
public:
	int getX() { return x; }
	int getY() { return y; }
};

