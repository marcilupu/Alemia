#include "PeaShooter.h"
int PeaShooter::spawnTime = 2000;
int PeaShooter::shootTime = 4000;