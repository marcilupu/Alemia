#include "Sun.h"
int Sun::sunSpawnTime = 5000;