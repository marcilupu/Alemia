#include "Projectile.h"
int Projectile::movementTime = 500;