  Aplicatia are 17 clase.

  8 dintre ele sunt singleton incluzand o clasa de exceptii,una de logare,console input si output,una pentru a incarca
mapa in functie de nivelul ales,una pentru a gestiona banii din joc,una pentru memorare a datelor player-ului si o
clasa Playgame in care este implementarea jocului.
  Entitatile sunt singurele elemente gestionate in joc(plante,zombie,pea,wallnut si cherry) prin intermediul unei interfete.
  Entitatile le-am organizat pe linie in 5 liste diferite,iar metodele pentru lupta,deplasare,etc. se fac prin functii
asupra fiecarei lista in parte.
  Zombie si Sun sunt implementati intr-un anumit interval de timp,iar miscarea unui zombie sau pea la fel.
  Pentru a alege o planta sau altceva se da un click pe caracterul din shop,urmat de click pentru locatia aferenta din joc,
pe linia pe care apare zombie-ul.Daca nu o sa dea eroare.
  Iar restul este distractie.

  Peashooter : P
  Zombie banal : Z
  Zombie buckethead : B
  Cherrybomb : C
  Wallnut : W
  Sunflower : S
  Pea : -