#pragma once

class Map
{
public:
	static void doLVL1();
	static void doLVL2();
	static void doLVL3();

	static void doWin();
	static void doLose();


};

