Prezentarea jocului:
Au fost implementate 4 plante
Si 2 zombie
Exista un meniu simplist in care se poate selecta intrarea in joc optiunile de nivel si iesirea;
Clasamentul nu este inca functional;
Bugs:
La clasa Player Names cand se introduce numele uneori Crapa, nu mi am dat seama inca de ce.
Uneori bullets urile trec prin zombie fara sa ii dea demage;
End.