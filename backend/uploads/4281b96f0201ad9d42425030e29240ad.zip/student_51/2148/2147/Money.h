#pragma once


class Money
{
private:
	int money;

public:
	Money();
	~Money();
	int GetMoney();
	void SetMoney(int mon);
};